setTimeout(() => {
    p1 = document.getElementById('p1')
    p1.innerText = 'World'
}, 2000)