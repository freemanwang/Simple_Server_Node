setTimeout(() => {
    p1 = document.getElementById('p1')
    p1.innerText = 'How are you'
    p1.style.color='red'
}, 3000)